int ibm_partition(struct parsed_partitions *, struct block_device *);
