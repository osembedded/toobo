/*
 *  fs/partitions/ultrix.h
 */

int ultrix_partition(struct parsed_partitions *state, struct block_device *bdev);
